module.exports = {
    cookieSecret: 'microblogcythilya',
    db: 'microblog',
    host: 'localhost',
};